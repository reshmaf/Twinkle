<?php
 
  session_start(); //Setting the required sessions if not set already
  require '../../dbconnect.php';
  require 'setsessionfortest.php';
  $NUMBER_OF_QUESTIONS_TO_BE_ASKED=10;
  $qnoCopy=0;
  $_SESSION['type']=1;
  //$_SESSION['start']=(date("i"));
  //if( $_SESSION['start'] > $_SESSION['end'] )
  //{
    
      // if($_POST['selectedOpt']==($_SESSION['questionObject']->rightChoice))
      //     {
        //       $_SESSION['score']++;//right answer
        // }
   //     header("Location: myscore.php");
   //}
 class FetchQuestion
   {
        function FetchQuestion($receivedQuesNumber, mysqli $scon)
        {
            $result = mysqli_query($scon,"SELECT * FROM questions WHERE qno=".$receivedQuesNumber);
            $quesRow = mysqli_fetch_array($result);
            $this->question = $quesRow['question'];
            $this->op1 = $quesRow['ans1'];
            $this->op2 = $quesRow['ans2'];
            $this->op3 = $quesRow['ans3'];
            $this->op4 = $quesRow['ans4'];
            $this->rightChoice = $quesRow['rightans'];
        }
   }

 // if session is not set this will redirect to login page

if($_SESSION['count'] == 1)
{
if(!isset($_POST['submit']))
      {
          if($_SESSION['count'] == 1)
          $qnoCopy = rand(1,50);
            array_push($_SESSION['questionNumbersAskedSoFar'], $qnoCopy);
          $_SESSION['questionObject'] = new FetchQuestion($qnoCopy,$scon);
      }
}
?>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="assets/css/mcq.css">

	<style> 
		input[type=submit] {
  			background-color: #4CAF50;
  			border: none;
  			color: white;
  			padding: 16px 32px;
  			text-decoration: none;
  			cursor: pointer;
  			border-radius: 5px;
		}
	</style>

</head>
<body>
	<div class="container">
		<h1 class="brand">Data Structures</h1>

		
		<div class="wrapper">
			<div class="company-info">
				<h3>QUESTION <?php echo $_SESSION['count'];?>:</h3>
					<li><?php echo $_SESSION['questionObject']->question ;?></li>
					
				
			</div>
			<div class="contact">
				<h3>Options</h3>
				<a href="reporterr.html" class="rep">Report</a>
				<form action="actions.php" method="post">
					
						
						<input type="radio" name="name" value="<?php echo $_SESSION['questionObject']->op1 ?>" ><?php echo $_SESSION['questionObject']->op1 ?><br><br>
					
						<input type="radio" name="name" value="<?php echo $_SESSION['questionObject']->op2 ?>"><?php echo $_SESSION['questionObject']->op2 ?><br><br>
					
						<input type="radio" name="name" value="<?php echo $_SESSION['questionObject']->op3 ?>"><?php echo $_SESSION['questionObject']->op3 ?><br><br>
					
						<input type="radio" name="name" value="<?php echo $_SESSION['questionObject']->op4 ?>"><?php echo $_SESSION['questionObject']->op4 ?><br><br><br>
					
						<center>
							<input type="submit" name="submit" value="Next">
						</center>
				
				</form>
				<div id="divCounter" style="width:auto; height:auto; display: inline-block; margin-top: 5%; background-color: #92BDE7; padding: 5px;"></div>
			</div>
		</div>
	</div>		
	<script type="text/javascript">
    if(localStorage.getItem("counter"))
    {
      if(localStorage.getItem("counter") <= 0)
      {
        //var value = 0;
          var value=90;
      }
      else
      {
          //var value=8;
        var value = localStorage.getItem("counter");
      }
    }   
    else
    {
        //var value=8;
        var value = 90;
        localStorage.setItem("counter", 90);
    }
    document.getElementById('divCounter').innerHTML = value;

    var counter = function (){
      if(value <= 0)
      { 
        localStorage.removeItem("counter");
        window.location="myscore.php";
          //localStorage.setItem("counter", 0);
        
      }
      else
      {
        value = parseInt(value)-1;
        localStorage.setItem("counter", value);
      }
      document.getElementById('divCounter').innerHTML = value;
    };

    var interval = setInterval(function (){counter();}, 1000);
  </script>	

</body>
</html>
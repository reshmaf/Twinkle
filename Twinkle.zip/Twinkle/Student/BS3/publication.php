<?php
session_start();
if ( !isset($_SESSION['Users'])!="" ) 
{
        header("Location: logout.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <meta http-equiv="X-UA-Compatible" content="ie=edge">
	 <link rel="stylesheet" href="assets/css/publication.css">
	 <title>Select the Category</title>
</head>
<body>
	<div class="container">
  <div class="split left">
    <h1>Post Article</h1>
    <a href="article.php" class="button">Article</a>
  </div>
  <div class="split right">
    <h1>Share Experience</h1>
    <a href="interview.php" class="button">Interview Experience</a>
  </div>
</div>
	<script src="main.js"></script>
</body>
</html>
		
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>User Profile</title>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.css" />
  <link rel="stylesheet" href="assets/css/profile.css">
  <style>
  .imgBx{
	width:auto;
	text-align:center;
	padding:20px;
	}
	img{
	max-width:100%;
	width:230px;
	height:270px;
	}
	</style>
</head>
<body>
  <div class="container">
    <h1 class="brand"><span>Student's</span> User Profile</h1>
    <div class="wrapper animated bounceInLeft">
      <div class="company-info">
        <h3>Edit Profile</h3>
		<div class="imgBx">
			<img src="assets/img/avatar.png"></br>
			
			<label for="img" class="label-title">Upload Image</label></br>
			<input type="file" id="imgs" required="required" accept="image/*">
			
		</div>
        
      </div>
      <div class="contact">
        <!--<h3>Email Us</h3>-->
        <form>
		  <p>
            <label>Username</label>
            <input type="text" name="uname" required="required">
          </p></br>
          <p>
            <label>First Name</label>
            <input type="text" name="fname" required="required">
          </p>
          <p>
            <label>Last Name</label>
            <input type="text" name="lname">
          </p>
		  <p>
            <label>Register Number</label>
            <input type="text" name="reg" required="required">
          </p>
		  <p>
			<label for="dep">Department</label>
			  <select id="Department" name="department">
			  <option value="CSE">CSE</option>
			  <option value="ECE">ECE</option>
			  <option value="EEE">EEE</option>
			  <option value="EI">EI</option>
			  <option value="IT">IT</option>
			  <option value="BioTech">BioTech</option>
			  <option value="Civil">Civil</option>
			  <option value="Mech">Mech</option>
			  </select>
		  </p>
		  
		
		 
          <p>
            <label>Email Address</label>
            <input type="email" name="email" required="required">
          </p>
          <p>
            <label>Phone Number</label>
            <input type="tel" name="phone">
          </p>
		  <p>
            <label>DOB</label>
            <input type="date" name="dob">
          </p></br>
		 
		 
		  <p>
            <label>Password</label>
            <input type="password" name="phone" required="required">
          </p>
		  <p>
            <label>Confirm Password</label>
            <input type="password" name="phone" required="required">
          </p>
          
          <p class="full">
            <button>Update</button>
          </p>
        </form>
      </div>
    </div>
  </div>
</body>
</html>
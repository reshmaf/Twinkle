<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Video Lectures</title>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.css" />
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 <!-- <link rel="stylesheet" type="text/css" href="videolecturescss.css">-->
  <style type="text/css">
    *{
    box-sizing: border-box;
  }

body{
  background:#efa8e4;
  color:#485e74;
  line-height:1.6;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  padding:1em;
}

@import url(//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css);

fieldset, label { margin: 0; padding: 0; }

.container{
  max-width:1500px;
  max-height: 5000px;
  margin-left:auto;
  margin-right:auto;
  padding:1em;
}

.brand{
  text-align: center;
}

.brand span{
  color:#fff;
}

.wrapper{
  box-shadow: 0 0 20px 0 rgba(72,94,116,0.7);
}

.wrapper > *{
  padding: 1em;
}

.company-info{
  background:#f8e1f4;
  
}

.company-info h3, .company-info ul{
  text-align: center;
  margin:0 0 1rem 0;
}

.contact{
  background:#fff0f5;
}

/* FORM STYLES */
.contact form{
  display: grid;
  grid-template-columns: 1fr 2fr;
  grid-gap:20px;
}

.contact form label .la{
  display:block;
}

.contact form p{
  margin:0;
}

.contact form .full{
  grid-column: 1 / 3;
}

.contact form button,.contact form textarea{
  width:1000px;
  padding:1em;
  border:1px solid #c9e6ff;
}

.contact form button{
  background:#97e5ef;
  border:0;
  text-transform: uppercase;
}

.contact form button:hover,.contact form button:focus{
  background:#92bde7;
  color:#fff;
  outline:0;
  transition: background-color 2s ease-out;
}

/* LARGE SCREENS */
@media(min-width:800px){
  .wrapper{
    display: grid;
    grid-template-columns: 0.6fr 3fr;
  }

  .wrapper > *{
    padding:0.5em;
  }

  .company-info h3, .company-info ul, .brand{
    text-align: left;
  }
}

/*input[type=text] {
  width: 130px;
  height: 20px;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 12px;
  background-color: white;
  background-image: url('C:\xampp\htdocs\Twinkle\Student\BS3\searchicon.jpg');
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 12px 0px 12px 40px;
  -webkit-transition: width 0.4s ease-in-out;
  transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
  width: 100%;
}*/

form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  height: 30px;
  width: 80%;
  background: white;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  height: 30px;
  background: #2196F3;
  color: white;
  font-size: 10px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
}


.fa {
  font-size: 100px;
  cursor: pointer;
  user-select: none;
}

.fa:hover {
  color: darkblue;
}

.fa {
  padding: 10px;
  font-size: 30px;
  width: 60px;
  height: 50px;
  text-align: center;
  text-decoration: none;
  margin:2px 2px;
  border-radius: 50%;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
}

.center {
  text-align: center;
}
.pagination{
  display: inline-block;
}
.pagination a {
  border: 1px solid #ddd;
  margin: 0 4px;
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
}



.pagination a.active {
  background-color: dodgerblue;
  color: white;
}

.pagination a:hover:not(.active) {background-color: dodgerblue;}

#three{
    width: 70%;
    height:500px;
    border: 1px solid lime; 
}
#thre{
    width: 22%;
    height:500px;
    border: 1px solid lime; 
    margin-left: 780px;
    margin-top:-500px;
}


  </style>
  <script>
function myFunction(x) {
  x.classList.toggle("fa-thumbs-down");
}
</script>

</head>
<body>
  <div class="container">
    <h1 class="brand"><span>Student</span> Online Assessment <span>Portal</span></h1>
    <div class="wrapper animated bounceInLeft">
      <div class="company-info">
        <h3 style="color:#efa8e4">Video Lectures</h3>
        <form class="example" action="#">
        <input type="text" placeholder="Search.." name="search">
  <button type="submit"><i class="fa fa-search" style="font-size: 20px; margin-left: -20px;margin-top: -20px;"></i></button></form>
        <p style="color: #efa8e4;background-color: #C860F2 ; text-align: center;font-weight: bold;margin: 7px; border-radius: 80px;"><a href="#" style="text-decoration: none;">Lecture 1</a></p>
        <p style="color: #efa8e4;background-color: #C860F2 ; text-align: center;font-weight: bold;margin: 7px; border-radius: 80px;"><a href="#" style="text-decoration: none;">Lecture 2</a></p>
        <p style="color: #efa8e4;background-color: #C860F2 ; text-align: center;font-weight: bold;margin: 7px; border-radius: 80px;"><a href="#" style="text-decoration: none;">Lecture 3</a></p>
        <p style="color: #efa8e4;background-color: #C860F2 ; text-align: center;font-weight: bold;margin: 7px; border-radius: 80px;"><a href="#" style="text-decoration: none;">Lecture 4</a></p>
        <p style="color:#efa8e4;font-weight: bold;">Share via</p>
        <a href="#" class="fa fa-facebook"></a>
        <a href="#" class="fa fa-twitter"></a>
        <a href="#" class="fa fa-google"></a>
        <a href="#" class="fa fa-linkedin"></a>
        <p style="color:#efa8e4;font-weight: bold;">Uploaded Staff Name:</p>
        <p style="color:#efa8e4;font-weight: bold;">Like / Dislike:
        <i onclick="myFunction(this)" class="fa fa-thumbs-up"></i></p>
      </div>
      <div class="contact">
       <p><label> <div id="three">
        </div></label>
        <label><div id="thre">Transcript
        </div></label>
      </p>
      <form>
      <p><label>Any Queries/Doubts?</label><br>
        <label><textarea rows="5" cols="103" class="full"></textarea></label>
        <button class="full">Submit</button></p>
      <p>  <div class="center">
          <div class="pagination">
            <a href="#">&laquo;</a>
            <a href="#">1</a>
            <a href="#">2</a>
            <a href="#">3</a>
            <a href="#">4</a>
            <a href="#">5</a>
            <a href="#">6</a>
            <a href="#">&raquo;</a>
          </div></div></p>
        </div>
      </form>
          <script>
var video = document.getElementById("myVideo");
var btn = document.getElementById("myBtn");

function Function() {
  if (video.paused) {
    video.play();
    btn.innerHTML = "Pause";
  } else {
    video.pause();
    btn.innerHTML = "Play";
  }
}
</script>
        </form>
      </div>
    </div>
  </div>
</body>
</html>